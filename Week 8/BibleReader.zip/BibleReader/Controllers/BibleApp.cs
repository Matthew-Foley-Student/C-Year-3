﻿using BibleReader.Models;
using Microsoft.AspNetCore.Mvc;
using MySqlConnector;
using System.Collections.Generic;

namespace BibleVerseApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VerseController
    {
        private readonly string _connectionString = "Server=localhost;Port=8889;Database=bible_verses;Uid=root;Pwd=root;";

        [HttpGet("getverse")]
        public List<BibleVerse> GetVerse(string book, int chapter, int verse)
        {
            var verses = new List<BibleVerse>();
            string query = "SELECT `akjv_books`.`name`, `akjv_verses`.`verse`, `akjv_verses`.`chapter`, `akjv_verses`.`text` FROM `akjv_books`  LEFT JOIN `akjv_verses` ON `akjv_verses`.`book_id` = `akjv_books`.`id` WHERE akjv_books.name = @name AND `akjv_verses`.`verse`= @verse AND `akjv_verses`.`chapter` = @chapter";

            // Using statement automatically disposes connection and command resources
            using (var conn = new MySqlConnection(_connectionString))
            {
                conn.Open();
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@name", book);
                    cmd.Parameters.AddWithValue("@chapter", chapter);
                    cmd.Parameters.AddWithValue("@verse", verse);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            verses.Add(new BibleVerse
                            {
                                Book = reader.GetString("name"),
                                Chapter = reader.GetInt32("chapter"),
                                Verse = reader.GetInt32("verse"),
                                Text = reader.GetString("text")
                            });
                        }
                    }
                }
            }
            return verses;
        }
    }
}
