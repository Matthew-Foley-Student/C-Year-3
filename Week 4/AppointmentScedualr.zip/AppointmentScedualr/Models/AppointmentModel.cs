﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace AppointmentScedualr.Models
{
    public class AppointmentModel
    {
        public AppointmentModel(string patientName, DateTime dateTime, decimal patientNetWorth, string doctorName, int painLevel)
        {
            this.patientName = patientName;
            this.dateTime = dateTime;
            PatientNetWorth = patientNetWorth;
            DoctorName = doctorName;
            PainLevel = painLevel;
        }

        [DisplayName("Patient Full Name")]
        [Required]
        [StringLength(50, MinimumLength = 4)]
        public string patientName { get; set; }

        [Required]        
        [DisplayName("Appointment Requested Date and Time")]
        [DataType(DataType.Date)]
        public DateTime dateTime { get; set; }

        [Required]    
        [DataType(DataType.Currency)]    
        [DisplayName("Patient Net Worth")]
        public decimal PatientNetWorth { get; set; }

        [DisplayName("Doctor Last Name")]
        [Required]
        public string DoctorName { get; set; }
 
        [Required]
        [Range(1, 10)]
        [DisplayName("Pain Level Scaled 1 Low 10 High")]
        public int PainLevel { get; set; }
    }
}
