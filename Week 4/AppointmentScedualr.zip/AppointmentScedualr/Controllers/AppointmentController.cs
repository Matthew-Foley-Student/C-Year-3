﻿using AppointmentScedualr.Models;
using Microsoft.AspNetCore.Mvc;

namespace AppointmentScedualr.Controllers
{
    public class AppointmentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ShowAppointmentDetails()
        {
            return View();
        }
    }
}
