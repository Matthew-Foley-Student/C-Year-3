﻿using ProductApp.Models;
using Microsoft.Data.SqlClient;

namespace ProductApp.Services
{
    public class ProductDAO : IProductDAO
    {
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ProductsDatabase;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False;Command Timeout=30";

        public async Task<int> AddProduct(ProductModel product)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Products (Name, Price, Description, CreatedAt, ImageUrl) OUTPUT INSERTED.Id VALUES (@Name, @Price, @Description, @CreatedAt, @ImageUrl)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Name", product.Name);
                cmd.Parameters.AddWithValue("@Price", product.Price);
                cmd.Parameters.AddWithValue("@Description", product.Description);
                cmd.Parameters.AddWithValue("@CreatedAt", product.CreatedAt);
                cmd.Parameters.AddWithValue("@ImageUrl", product.ImageUrl);

                conn.Open();
                int newId = (int)await cmd.ExecuteScalarAsync();
                return newId;
            }
        }
        public async Task<IEnumerable<ProductModel>> GetAllProducts()
        {
            List<ProductModel> products = new List<ProductModel>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Products", conn);
                conn.Open();
                SqlDataReader reader = await cmd.ExecuteReaderAsync();
                while (reader.Read())
                {
                    products.Add(new ProductModel
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                        Price = reader.IsDBNull(2) ? 0 : reader.GetDecimal(2),
                        Description = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                        CreatedAt = reader.IsDBNull(4) ? DateTime.MinValue : reader.GetDateTime(4),
                        ImageUrl = reader.IsDBNull(5) ? string.Empty : reader.GetString(5)
                    });
                }
            }
            return products;
        }

        public Task DeleteProduct(ProductModel product)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Products WHERE Id = @Id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Id", product.Id);
                conn.Open();
                return  cmd.ExecuteNonQueryAsync();
            }
        }



        public Task<ProductModel> GetProductById(int id)
        {
            ProductModel product = null;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Products WHERE Id = @Id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Id", id);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    product = new ProductModel
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                        Price = reader.IsDBNull(2) ? 0 : reader.GetDecimal(2),
                        Description = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                        CreatedAt = reader.IsDBNull(4) ? DateTime.MinValue : reader.GetDateTime(4),
                        ImageUrl = reader.IsDBNull(5) ? string.Empty : reader.GetString(5)
                    };
                }
            }
            return Task.FromResult(product);
        }

        public Task<IEnumerable<ProductModel>> SearchForProductByDescription(string searchTerm)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<ProductModel>> SearchForProductByName(string searchTerm)
        {
            throw new NotImplementedException();
        }

        public async Task UpdateProduct(ProductModel product)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "UPDATE Products SET Name = @Name, Price = @Price, Description = @Description, CreatedAt = @CreatedAt, ImageUrl = @ImageUrl WHERE Id = @Id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Name", product.Name);
                cmd.Parameters.AddWithValue("@Price", product.Price);
                cmd.Parameters.AddWithValue("@Description", product.Description);
                cmd.Parameters.AddWithValue("@CreatedAt", product.CreatedAt);
                cmd.Parameters.AddWithValue("@ImageUrl", product.ImageUrl);
                cmd.Parameters.AddWithValue("@Id", product.Id);
                conn.Open();
                await cmd.ExecuteNonQueryAsync();
            }

        }
    }
}
