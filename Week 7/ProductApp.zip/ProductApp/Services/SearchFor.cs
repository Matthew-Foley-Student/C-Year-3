﻿namespace ProductApp.Services
{
    public class SearchFor
    {
        public string SearchTerm { get; internal set; }
        public bool InTitle { get; internal set; }
        public bool InDescription { get; internal set; }
    }
}