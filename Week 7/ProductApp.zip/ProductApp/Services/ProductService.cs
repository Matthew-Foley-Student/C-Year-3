﻿using ProductApp.Models;
using System.Data.SqlClient;

namespace ProductApp.Services
{
    public class ProductService : IProductServices
    {
        private readonly IProductDAO _productsDAO;
        private readonly IProductMapper _productMapper;

        public ProductService(IProductDAO productsDAO, IProductMapper productMapper)
        {
            _productsDAO = productsDAO;
            _productMapper = productMapper;
        }
        public async Task<int> AddProduct(ProductViewModel product)
        {
            var productDTO = _productMapper.ToDTO(product);
            var productModel = _productMapper.ToModel(productDTO);
            return await _productsDAO.AddProduct(productModel);
        }

        public async Task DeleteProduct(string id)
        {
            int productId= int.Parse(id);
            var productModel = await _productsDAO.GetProductById(productId);
            if (productModel != null)
            {
                await _productsDAO.DeleteProduct(productModel);
            }
        }

        public async Task<IEnumerable<ProductViewModel>> GetAllProducts()
        {
            IEnumerable<ProductModel> productModels = await _productsDAO.GetAllProducts();
            List<ProductViewModel> productViewModels = new List<ProductViewModel>();
            foreach (ProductModel productModel in productModels)
            {
                ProductDTO productDTO = _productMapper.ToDTO(productModel);
                ProductViewModel productViewModel = _productMapper.ToViewModel(productDTO);
                productViewModels.Add(productViewModel);
            }
            return productViewModels;
        }

        public async Task<ProductViewModel> GetProductById(int id)
        {
            var productModel = await _productsDAO.GetProductById(id);
            var productDTO = _productMapper.ToDTO(productModel);
            return _productMapper.ToViewModel(productDTO);
        }

        public async Task<IEnumerable<ProductViewModel>> SearchForProducts(SearchFor searchTerm)
        {
            throw new NotImplementedException();
        }

        public async Task UpdateProduct(ProductViewModel product)
        {
            var productDTO = _productMapper.ToDTO(product);
            var productModel = _productMapper.ToModel(productDTO);
            await _productsDAO.UpdateProduct(productModel);
        }
    }
}
