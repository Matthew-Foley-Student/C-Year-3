﻿using ProductApp.Models;

namespace ProductApp.Services
{
    public interface IProductDAO
    {
        Task<IEnumerable<ProductModel>> GetAllProducts();
        Task<ProductModel> GetProductById(int id);
        Task<int> AddProduct(ProductModel product);
        Task UpdateProduct(ProductModel product);
        Task DeleteProduct(ProductModel product);
        Task<IEnumerable<ProductModel>> SearchForProductByName(string searchTerm);
        Task<IEnumerable<ProductModel>> SearchForProductByDescription(string searchTerm);

    }
}
