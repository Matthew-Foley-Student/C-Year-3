﻿using ProductApp.Models;

namespace ProductApp.Services
{
    public class ProductMapper : IProductMapper
    {
        public ProductMapper(string currencyFormat, string dateFormat, decimal taxRate)
        {
            CurrencyFormat = currencyFormat;
            DateFormat = dateFormat;
            TaxRate = taxRate;
        }

        public string CurrencyFormat { get; set; } = "C";
        public string DateFormat { get; set; } = "D";
        public decimal TaxRate { get; set; } = .08m;

        public ProductDTO ToDTO(ProductModel model)
        {
            return new ProductDTO
            {
                Id = model.Id.ToString(),
                Name = model.Name,
                Price = model.Price,
                Description = model.Description,
                CreatedAt = model.CreatedAt,
                ImageUrl = model.ImageUrl,
                EstimatedTax = model.Price * TaxRate,
                FormattedPrice = model.Price.ToString(CurrencyFormat),
            };

        }
        public ProductModel ToModel(ProductDTO dto)
        {
            if(dto.Id == null)
            {
                return new ProductModel
                {
                    Name = dto.Name,
                    Price = dto.Price,
                    Description = dto.Description,
                    CreatedAt = (DateTime)dto.CreatedAt,
                    ImageUrl = dto.ImageUrl ?? string.Empty
                };
            }

            return new ProductModel
            {
                Id = int.Parse(dto.Id),
                Name = dto.Name,
                Price = dto.Price,
                Description = dto.Description,
                CreatedAt = (DateTime)dto.CreatedAt,
                ImageUrl = dto.ImageUrl ?? string.Empty
            };
        }

        public ProductDTO ToDTO(ProductViewModel viewModel)
        {
            if (viewModel.Id == null)
            {
                return new ProductDTO
                {
                    Name = viewModel.Name,
                    Price = viewModel.Price,
                    Description = viewModel.Description,
                    CreatedAt = viewModel.CreatedAt,
                    ImageUrl = viewModel.ImageUrl
                };
            }

            return new ProductDTO
            {
                Id = viewModel.Id,
                Name = viewModel.Name,
                Price = viewModel.Price,
                Description = viewModel.Description,
                CreatedAt = viewModel.CreatedAt,
                ImageUrl = viewModel.ImageUrl
                };
        }



        public ProductViewModel ToViewModel(ProductDTO dto)
        {
            return new ProductViewModel
            {
                Id = dto.Id,
                Name = dto.Name,
                Price = dto.Price,
                Description = dto.Description,
                CreatedAt = (DateTime)dto.CreatedAt,
                ImageUrl = dto.ImageUrl,
                EstimatedTax = dto.EstimatedTax,
                FormattedPrice = dto.FormattedPrice,
                FormattedCreatedAt = dto.FormattedCreatedAt
            };
        }
    }
}
