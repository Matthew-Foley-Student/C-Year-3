﻿using ProductApp.Models;

namespace ProductApp.Services
{
    public interface IProductServices
    {
        Task<IEnumerable<ProductViewModel>> GetAllProducts();
        Task<ProductViewModel> GetProductById(int id);        
        Task<int> AddProduct(ProductViewModel product);
        Task UpdateProduct(ProductViewModel product);
        Task DeleteProduct(string id);
        Task<IEnumerable<ProductViewModel>> SearchForProducts(SearchFor searchTerm);
    }
}
