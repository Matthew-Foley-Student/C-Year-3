using Microsoft.AspNetCore.Mvc;
using ProductApp.Models;
using ProductApp.Services;
using System.Diagnostics;

namespace ProductApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly IProductServices _productService;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public HomeController(IProductServices productServices, IWebHostEnvironment webHostEnvironment)
        {
            _productService = productServices;
            _webHostEnvironment = webHostEnvironment;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult ShowCreatedProductForm()
        {
            ViewBag.Images = GetImageName();
            ViewBag.TaxRate = 0.08;
            var productViewModel = new ProductViewModel();
            productViewModel.CreatedAt = DateTime.Now;
            return View(productViewModel);
        }

        private List<string> GetImageName()
        {
            string imagesPath = Path.Combine(_webHostEnvironment.WebRootPath, "images");
            if (!Directory.Exists(imagesPath))
            {
                Directory.CreateDirectory(imagesPath);
            }
            return Directory.EnumerateFiles(imagesPath).Select(fileName => Path.GetFileName(fileName)).ToList();
        }

        [HttpPost]
        public async Task<IActionResult> CreateProduct(ProductViewModel productViewModel)
        {
            if (ModelState.IsValid)
            {
                if (productViewModel.ImageFile != null)
                {
                    productViewModel.ImageUrl = await PerformFileUpload(productViewModel);
                }
                await _productService.AddProduct(productViewModel);
                return RedirectToAction(nameof(Index));
            }
            else
            {
                ViewBag.Images = GetImageName();
                ViewBag.TaxRate = 0.08;
                return View("ShowCreatedProductForm", productViewModel);
            }


        }


        private async Task<string> PerformFileUpload(ProductViewModel productViewModel)
        {
            string uniqueFileName = "";
            if (productViewModel.ImageFile != null && productViewModel.ImageFile.Length > 0)
            {
                string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images");
                uniqueFileName = Guid.NewGuid().ToString() + "_" + productViewModel.ImageFile.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await productViewModel.ImageFile.CopyToAsync(fileStream);
                }
            }
            return uniqueFileName;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ??
                HttpContext.TraceIdentifier
            });
        }

        public async Task<IActionResult> ShowAllProducts()
        {
            IEnumerable<ProductViewModel> products = await _productService.GetAllProducts();
            return View(products);
        }
        public async Task<IActionResult> ShowProductsOnGrid()
        {
            List<ProductViewModel> products = _productService.GetAllProducts().Result.ToList();
            return View(products);
        }
        public async Task<IActionResult> DeleteProduct(string id)
        {
            await _productService.DeleteProduct(id.ToString());
            return RedirectToAction(nameof(ShowAllProducts));
        }

        public async Task<IActionResult> ShowUpdatedFrom(int id)
        {
            ViewBag.Images = GetImageName();
            ViewBag.TaxRate = 0.08m;
            ProductViewModel product = await _productService.GetProductById(id);
            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateProduct(ProductViewModel productViewModel)
        {
            if (ModelState.IsValid)
            {
                if (productViewModel.ImageFile != null)
                {
                    productViewModel.ImageUrl = await PerformFileUpload(productViewModel);
                }
                await _productService.UpdateProduct(productViewModel);
                ProductViewModel product = await _productService.GetProductById(int.Parse(productViewModel.Id));
                return PartialView("_ProductCard", product);
            }
            else
            {
                ViewBag.Images = GetImageName();
                ViewBag.TaxRate = 0.08;
                return View("ShowUpdatedFrom", productViewModel);
            }

        }
    }
}
