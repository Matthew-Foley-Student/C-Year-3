using Microsoft.AspNetCore.Mvc;
using ProductApp.Models;
using ProductApp.Services;
using System.Diagnostics;

namespace ProductApp.Controllers
{
    [ApiController]
    [Route("api/v1/products")]
    public class ProductRestController : ControllerBase
    {
        private readonly ILogger<ProductRestController> _logger;
        private readonly IProductServices _productService;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly IConfiguration _configuration;

        public ProductRestController(ILogger<ProductRestController> logger, IProductServices productServices, IWebHostEnvironment webHostEnvironment, IConfiguration configuration)
        {
            _logger = logger;
            _productService = productServices;
            _webHostEnvironment = webHostEnvironment;
            _configuration = configuration;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ProductViewModel>> GetProductById(int id)
        {
            var product = await _productService.GetProductById(id);
            if(product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductViewModel>>> ShowAllProducts()
        {
            IEnumerable<ProductViewModel> products = await _productService.GetAllProducts();
            return Ok(products);
        }

        [HttpGet("search")]
        public async Task<ActionResult<IEnumerable<ProductViewModel>>> SearchForProducts([FromQuery] string searchTerm, [FromQuery] bool inTitle, [FromQuery] bool inDescription)
        {
            SearchFor searchFor = new SearchFor
            {
                SearchTerm = searchTerm,
                InTitle = inTitle,
                InDescription = inDescription
            };
            var searchResults = await _productService.SearchForProducts(searchFor);
            if(searchResults == null || !searchResults.Any())
            {
                return NotFound("No Product Was Found With SearchCriteria");
            }
            return Ok(searchResults);
        }
    }
}
