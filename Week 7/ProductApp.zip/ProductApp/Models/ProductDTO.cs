﻿namespace ProductApp.Models
{
    public class ProductDTO
    {
        public string? Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string? Description { get; set; }
        public DateTime? CreatedAt { get; set; }
        public string? ImageUrl { get; set; }
        public decimal EstimatedTax { get; internal set; }
        public string FormattedPrice { get; internal set; }
        public string FormattedCreatedAt { get; internal set; }
    }
}
