﻿using System.ComponentModel.DataAnnotations;

namespace ProductApp.Models
{
    public class ProductViewModel
    {
        public string? Id { get; set; }


        [Required]
        public string Name { get; set; }


        [Required]
        [Range(0, double.MaxValue, ErrorMessage = "Price must be a positive value.")]
        public decimal Price { get; set; }
        [Display(Name = "Price")]
        public string? FormattedPrice { get; set; }


      [Required]
        public string? Description { get; set; }


        [DataType(DataType.Date)]
        public DateTime CreatedAt { get; set; }
        [Display(Name = "Created At")]
        public string? FormattedCreatedAt { get; set; }


        public string? ImageUrl { get; set; }
        [Display(Name = "Upload Image")]
        public IFormFile? ImageFile { get; set; }


        public decimal EstimatedTax { get; set; }
        [Display(Name = "Estimated Tax")]
        public string? FormattedEstimatedTax { get; set; }
    }
}
