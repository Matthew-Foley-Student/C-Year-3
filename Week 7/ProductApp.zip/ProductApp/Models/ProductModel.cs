﻿namespace ProductApp.Models
{
    public class ProductModel
    {
        public ProductModel(int id, string name, decimal price, string description, DateTime createdAt, string imageUrl)
        {
            Id = id;
            Name = name;
            Price = price;
            Description = description;
            CreatedAt = createdAt;
            ImageUrl = imageUrl;
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
        public DateTime CreatedAt { get; set; }
        public string ImageUrl { get; set; }


        public ProductModel() 
        { 
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as ProductModel);
        }

        public bool Equals(ProductModel other)
        {
            return other != null &&
                   Id == other.Id;
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }
    }
}

