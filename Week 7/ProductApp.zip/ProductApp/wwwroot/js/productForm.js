﻿function updateComputedFields(taxRate) {
    var price = parseFloat($('#Price').val());
    if (!isNaN(price)) {
        var tax = price * taxRate;
        var formattedTax = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(tax);
        $('#FormattedEstimatedTax').val(formattedTax);
    }
}

function toggleImageInput() {
    var imageFileInput = $('#ImageFile');
    var imageUrl = $('#ImageUrl').val();
    if (imageFile.val()) {
        imageUrl.prop('disabled', true);
        imageUrl.val("");
    }
    else {
        imageUrl.prop('disabled', false);
    }
    if (imageUrl.val()) {
        imageFileInput.prop('disabled', true);
        imageFileInput.val("");
    }
    else {
        imageFileInput.prop('disabled', false);
    }
}

function bindDynamicEvents(taxRate) {
    $('#Price').on('input', function () {
        updateComputedFields(taxRate);
    });
    $('#ImageFile, #ImageUrl').on('input change', toggleImageInput);
}
function initializeForm(taxRate) {
    updateComputedFields(taxRate);
    toggleImageInput();
    bindDynamicEvents(taxRate);
}