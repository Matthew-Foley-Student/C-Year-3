﻿function bindEditProductEvents(taxRate) {
    $(document).on('click', '.edit-product', function (e) {
        e.preventDefault();

        var productId = $(this).data('id');
        alert("You Clicked The Edit Button For Product ID: " + productId + ".");
        $.ajax({
            url: '/Home/ShowUpdateModal',
            data: { id: productId },
            success: function (result) {
                alert(result);
                $('#editProductModal .modal-content').html(result);
                var modal = new bootstrap.Modal(document.getElementById('editProductModal'));
                modal.show();
            },
            error: function () {
                console.error('An error occurred while loading the edit modal.');
            }
        });
    });
}