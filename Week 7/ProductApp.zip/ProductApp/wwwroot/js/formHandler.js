﻿function bindFormSubmission() {
    $(document).on('submit', 'form', function (e) {
        e.preventDefault();
        alert("Form Submit Is Being Handled By AJAX Instead Of Default");
        var form = $(this);
        $.ajax({
            url: 'Home/UpdateProductFormModal',
            type: 'POST',
            data: form.serialize(),
            success: function (response) {
                alert(response);
                var productId = form.find('input[name=Id]').val();
                $('div[data-id="' + productionId + '"].card').replaceWith(response);
                model.hide();
            },
            error: function () {
                console.error('An Error Occured While Updateing');
            }
        });
    });
}