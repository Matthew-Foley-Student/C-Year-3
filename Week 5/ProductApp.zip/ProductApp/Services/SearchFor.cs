﻿namespace ProductApp.Services
{
    public class SearchFor
    {
    }
}