﻿using ProductApp.Models;

namespace ProductApp.Services
{
    public interface IProductServices
    {
        Task<IEnumerable<ProductViewModel>> GetAllProducts();
        Task<ProductModel> GetProductById(string id);        
        Task<int> AddProduct(ProductViewModel product);
        Task UpdateProduct(ProductViewModel product);
        Task DeleteProduct(string id);
        Task<IEnumerable<ProductModel>> SearchForProducts(SearchFor searchTerm);
    }
}
